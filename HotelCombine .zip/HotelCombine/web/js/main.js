/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */

document.addEventListener("DOMContentLoaded", function() {

    let btnIcons = document.querySelector('#login-btn');
    let loginForm = document.querySelector('.login-form-container');
    let formClose = document.querySelector('#form-close');

    let menu = document.querySelector('#menu-bar');
    let navbar = document.querySelector('.navbar');

    let videoBtn = document.querySelectorAll('.vid-btn');

    window.onscroll = () => {
        if (menu) menu.classList.remove('fa-xmark');
        if (navbar) navbar.classList.remove('active');
        // if (loginForm) loginForm.classList.remove('active');
    };

    if(menu && navbar) {
        menu.addEventListener('click', () => {
            menu.classList.toggle('fa-xmark');
            navbar.classList.toggle('active');
        });
    }


    if(btnIcons && loginForm) {
        btnIcons.addEventListener('click', () => {
            loginForm.classList.add('active');
        });
    }

    if(formClose && loginForm) {
        formClose.addEventListener('click', () => {
            loginForm.classList.remove('active');
        });
    }

    // Avatar dropdown
    var avatarBtn = document.getElementById("avatarBtn");
    var dropdownMenu = document.getElementById("dropdownMenu");
    if (avatarBtn && dropdownMenu) {
        avatarBtn.addEventListener("click", function(e) {
            dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
            e.stopPropagation();
        });
        document.addEventListener("click", function() {
            dropdownMenu.style.display = "none";
        });
        dropdownMenu.addEventListener("click", function(e){
            e.stopPropagation();
        });
    }

    videoBtn.forEach(btn => {
        btn.addEventListener('click', () => {
            let current = document.querySelector('.controls .active');
            if (current) current.classList.remove('active');
            btn.classList.add('active');
            let src = btn.getAttribute('data-src');
            let video = document.querySelector('#video-slider');
            if (video) video.src = src;
        });
    });

    var swiper = new Swiper(".mySwiper", {
        slidesPerView: 3,
        slidesPerGroup: 3,
        pagination: {
            el: ".swiper-pagination",
            type: "progressbar"
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        },
        breakpoints: {
            0: {
                slidesPerView: 1,
                slidesPerGroup: 1
            },
            768: {
                slidesPerView: 2,
                slidesPerGroup: 2
            },
            1024: {
                slidesPerView: 3,
                slidesPerGroup: 3
            }
        }
    });
});


