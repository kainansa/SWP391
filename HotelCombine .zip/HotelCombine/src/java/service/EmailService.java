/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.Properties;
import jakarta.mail.*;
import jakarta.mail.internet.*;

/**
 *
 * @author A
 */
public class EmailService {

    private final String username = "paradisehotelservice@gmail.com"; // đổi thành email của bạn
    private final String password = "oxeo utsj kjxy gswe";    // đổi thành app password

    private Properties getProperties() {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        return props;
    }

    /**
     * Gửi mail có đặt reply-to về email khách.
     */
    public void sendContactEmail(
            String to, // Email bạn muốn nhận liên hệ (thường là email quản lý)
            String customerName, // Tên khách nhập form
            String customerEmail, // Email khách nhập form
            String customerPhone, // SĐT khách nhập form
            String title, // Tiêu đề khách nhập form
            String messageContent // Nội dung khách nhập form
    ) throws Exception {
        String subject = "Title: " + title;
        String content
                = "Name: " + customerName + "\n"
                + "Email: " + customerEmail + "\n"
                + "Phone: " + customerPhone + "\n"
                + "Message: " + messageContent;

        Session session = Session.getInstance(getProperties(),
                new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(username, "Hotel Website Contact"));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
        message.setSubject(subject);
        message.setContent(content, "text/plain; charset=UTF-8");

        // Đặt Reply-To là email khách
        message.setReplyTo(InternetAddress.parse(customerEmail));

        Transport.send(message);
    }

    public void sendOtpEmail(String to, String otp) throws Exception {
        String subject = "Your OTP for password reset";
        String content = "Your OTP code is: " + otp + ". The code is valid for 5 minutes.";
        sendEmail(to, subject, content);
    }

    public void sendEmail(String to, String subject, String content) throws Exception {
        Session session = Session.getInstance(getProperties(),
                new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(username, "Hotel Website"));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
        message.setSubject(subject);
        message.setContent(content, "text/plain; charset=UTF-8");
        Transport.send(message);
    }

}
