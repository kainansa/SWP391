package model;

import java.util.Date;

public class Account {
    private int accountId;
    private Integer accountTypeID; // nếu không cần thì bỏ dòng này đi
    private String avatar;
    private String email;
    private String password_hash;
    private String fullName;
    private String phone;
    private String role;
    private boolean status;
    private Date createdAt;

    public Account() {
    }

    // Constructor đầy đủ
    public Account(int accountId, Integer accountTypeID, String email, String password_hash,
                   String fullName, String phone, String role, boolean status, Date createdAt, String avatar) {
        this.accountId = accountId;
        this.accountTypeID = accountTypeID;
        this.email = email;
        this.password_hash = password_hash;
        this.fullName = fullName;
        this.phone = phone;
        this.role = role;
        this.status = status;
        this.createdAt = createdAt;
        this.avatar = avatar;
    }

    // Constructor không có accountTypeID (tuỳ trường hợp dùng)
    public Account(int accountId, String email, String password_hash,
                   String fullName, String phone, String role, boolean status, Date createdAt, String avatar) {
        this(accountId, null, email, password_hash, fullName, phone, role, status, createdAt, avatar);
    }

    // Getter & Setter
    public int getAccountId() {
        return accountId;
    }
    public void setAccountId(int accountId) {
        this.accountId = accountId;
    }

    public Integer getAccountTypeID() {
        return accountTypeID;
    }
    public void setAccountTypeID(Integer accountTypeID) {
        this.accountTypeID = accountTypeID;
    }

    public String getAvatar() {
        return avatar;
    }
    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword_hash() {
        return password_hash;
    }
    public void setPassword_hash(String password_hash) {
        this.password_hash = password_hash;
    }

    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }

    public boolean isStatus() {
        return status;
    }
    public void setStatus(boolean status) {
        this.status = status;
    }

    public Date getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
