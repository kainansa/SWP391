/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author MSILap
 */
public class Services {
    private int ServiceID;
    private String ServiceName;
    private String Category;
    private double PurchasePrice;
    private  double SalePrice;
    private int IsReturnable;
    private int Quantity;
    private Date ManufactureDate;
    private Date ExpiryDate;
    private String Description;
    private String UsageStatus;

    public Services() {
    }

    public Services(int ServiceID, String ServiceName, String Category, double PurchasePrice, double SalePrice, int IsReturnable, int Quantity, Date ManufactureDate, Date ExpiryDate, String Description, String UsageStatus) {
        this.ServiceID = ServiceID;
        this.ServiceName = ServiceName;
        this.Category = Category;
        this.PurchasePrice = PurchasePrice;
        this.SalePrice = SalePrice;
        this.IsReturnable = IsReturnable;
        this.Quantity = Quantity;
        this.ManufactureDate = ManufactureDate;
        this.ExpiryDate = ExpiryDate;
        this.Description = Description;
        this.UsageStatus = UsageStatus;
    }
    public int getServiceID() {
        return ServiceID;
    }

    public void setServiceID(int ServiceID) {
        this.ServiceID = ServiceID;
    }

    public String getServiceName() {
        return ServiceName;
    }

    public void setServiceName(String ServiceName) {
        this.ServiceName = ServiceName;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String Category) {
        this.Category = Category;
    }

    public double getPurchasePrice() {
        return PurchasePrice;
    }

    public void setPurchasePrice(double PurchasePrice) {
        this.PurchasePrice = PurchasePrice;
    }

    public double getSalePrice() {
        return SalePrice;
    }

    public void setSalePrice(double SalePrice) {
        this.SalePrice = SalePrice;
    }

    public int getIsReturnable() {
        return IsReturnable;
    }

    public void setIsReturnable(int IsReturnable) {
        this.IsReturnable = IsReturnable;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    public Date getManufactureDate() {
        return ManufactureDate;
    }

    public void setManufactureDate(Date ManufactureDate) {
        this.ManufactureDate = ManufactureDate;
    }

    public Date getExpiryDate() {
        return ExpiryDate;
    }

    public void setExpiryDate(Date ExpiryDate) {
        this.ExpiryDate = ExpiryDate;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getUsageStatus() {
        return UsageStatus;
    }

    public void setUsageStatus(String UsageStatus) {
        this.UsageStatus = UsageStatus;
    }    
}
