/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author A
 */
public class Employees {
    private int EmployeeID;
    private String FullName;
    private String Email;
    private String Phone;
    private String Role;
    private String Username;
    private String PasswordHash;
    private Date HireDate;

    public Employees() {
    }

    public Employees(int EmployeeID, String FullName, String Email, String Phone, String Role, String Username, String PasswordHash, Date HireDate) {
        this.EmployeeID = EmployeeID;
        this.FullName = FullName;
        this.Email = Email;
        this.Phone = Phone;
        this.Role = Role;
        this.Username = Username;
        this.PasswordHash = PasswordHash;
        this.HireDate = HireDate;
    }

    public int getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(int EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public String getRole() {
        return Role;
    }

    public void setRole(String Role) {
        this.Role = Role;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPasswordHash() {
        return PasswordHash;
    }

    public void setPasswordHash(String PasswordHash) {
        this.PasswordHash = PasswordHash;
    }

    public Date getHireDate() {
        return HireDate;
    }

    public void setHireDate(Date HireDate) {
        this.HireDate = HireDate;
    }
    
    
}
