package model;

import java.sql.Timestamp;

public class Payment {
    private int paymentID;
    private int userID; // AccountID
    private int bookingID;
    private double amount;
    private double serviceAmount;
    private Timestamp paymentTime;
    private String status;
    private String note;
    private String staffFeedback;
    private Integer staffID;
    private Timestamp confirmedAt;

    // --- Getter/Setter đầy đủ ---
    public int getPaymentID() { return paymentID; }
    public void setPaymentID(int paymentID) { this.paymentID = paymentID; }

    public int getUserID() { return userID; }
    public void setUserID(int userID) { this.userID = userID; }

    public int getBookingID() { return bookingID; }
    public void setBookingID(int bookingID) { this.bookingID = bookingID; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public double getServiceAmount() { return serviceAmount; }
    public void setServiceAmount(double serviceAmount) { this.serviceAmount = serviceAmount; }

    public Timestamp getPaymentTime() { return paymentTime; }
    public void setPaymentTime(Timestamp paymentTime) { this.paymentTime = paymentTime; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }

    public String getStaffFeedback() { return staffFeedback; }
    public void setStaffFeedback(String staffFeedback) { this.staffFeedback = staffFeedback; }

    public Integer getStaffID() { return staffID; }
    public void setStaffID(Integer staffID) { this.staffID = staffID; }

    public Timestamp getConfirmedAt() { return confirmedAt; }
    public void setConfirmedAt(Timestamp confirmedAt) { this.confirmedAt = confirmedAt; }

    // Constructor đầy đủ nếu dùng (tùy code)
    public Payment() {}

    public Payment(int paymentID, int userID, int bookingID, double amount, double serviceAmount, Timestamp paymentTime, String status, String note, String staffFeedback, Integer staffID, Timestamp confirmedAt) {
        this.paymentID = paymentID;
        this.userID = userID;
        this.bookingID = bookingID;
        this.amount = amount;
        this.serviceAmount = serviceAmount;
        this.paymentTime = paymentTime;
        this.status = status;
        this.note = note;
        this.staffFeedback = staffFeedback;
        this.staffID = staffID;
        this.confirmedAt = confirmedAt;
    }
}
