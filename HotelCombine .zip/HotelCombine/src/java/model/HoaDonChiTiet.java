/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author MSILap
 */
public class HoaDonChiTiet {
    private int InvoiceDetailID;
    private int InvoiceID;
    private int ServiceID;
    private int RoomID;
    private int Quantity;
    private int ReturnedDrinkQuantity;
    private double RoomRentalTotal;
    private double ServiceTotal;
    private double GrandTotal;
    private double Surcharge;

    public HoaDonChiTiet() {
    }

    public HoaDonChiTiet(int InvoiceDetailID, int InvoiceID, int ServiceID, int RoomID, int Quantity, int ReturnedDrinkQuantity, double RoomRentalTotal, double ServiceTotal, double GrandTotal, double Surcharge) {
        this.InvoiceDetailID = InvoiceDetailID;
        this.InvoiceID = InvoiceID;
        this.ServiceID = ServiceID;
        this.RoomID = RoomID;
        this.Quantity = Quantity;
        this.ReturnedDrinkQuantity = ReturnedDrinkQuantity;
        this.RoomRentalTotal = RoomRentalTotal;
        this.ServiceTotal = ServiceTotal;
        this.GrandTotal = GrandTotal;
        this.Surcharge = Surcharge;
    }

    public int getInvoiceDetailID() {
        return InvoiceDetailID;
    }

    public void setInvoiceDetailID(int InvoiceDetailID) {
        this.InvoiceDetailID = InvoiceDetailID;
    }

    public int getInvoiceID() {
        return InvoiceID;
    }

    public void setInvoiceID(int InvoiceID) {
        this.InvoiceID = InvoiceID;
    }

    public int getServiceID() {
        return ServiceID;
    }

    public void setServiceID(int ServiceID) {
        this.ServiceID = ServiceID;
    }

    public int getRoomID() {
        return RoomID;
    }

    public void setRoomID(int RoomID) {
        this.RoomID = RoomID;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    public int getReturnedDrinkQuantity() {
        return ReturnedDrinkQuantity;
    }

    public void setReturnedDrinkQuantity(int ReturnedDrinkQuantity) {
        this.ReturnedDrinkQuantity = ReturnedDrinkQuantity;
    }

    public double getRoomRentalTotal() {
        return RoomRentalTotal;
    }

    public void setRoomRentalTotal(double RoomRentalTotal) {
        this.RoomRentalTotal = RoomRentalTotal;
    }

    public double getServiceTotal() {
        return ServiceTotal;
    }

    public void setServiceTotal(double ServiceTotal) {
        this.ServiceTotal = ServiceTotal;
    }

    public double getGrandTotal() {
        return GrandTotal;
    }

    public void setGrandTotal(double GrandTotal) {
        this.GrandTotal = GrandTotal;
    }

    public double getSurcharge() {
        return Surcharge;
    }

    public void setSurcharge(double Surcharge) {
        this.Surcharge = Surcharge;
    }
    
}
