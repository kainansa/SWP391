/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author MSILap
 */
public class HoaDon {
    private int maHoaDon;
    private int khachHang;
    private int khuyenMai;
    private int nhanVien;
    private Date ngayLapHoaDon;
    private double thue;
    private double tongThanhTienBanDau;
    private double tongThanhTienPhaiTra;

    public HoaDon() {
    }

    public int getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(int maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public int getKhachHang() {
        return khachHang;
    }

    public void setKhachHang(int khachHang) {
        this.khachHang = khachHang;
    }

    public int getKhuyenMai() {
        return khuyenMai;
    }

    public void setKhuyenMai(int khuyenMai) {
        this.khuyenMai = khuyenMai;
    }

    public int getNhanVien() {
        return nhanVien;
    }

    public void setNhanVien(int nhanVien) {
        this.nhanVien = nhanVien;
    }

    public Date getNgayLapHoaDon() {
        return ngayLapHoaDon;
    }

    public void setNgayLapHoaDon(Date ngayLapHoaDon) {
        this.ngayLapHoaDon = ngayLapHoaDon;
    }

    public double getThue() {
        return thue;
    }

    public void setThue(double thue) {
        this.thue = thue;
    }

    public double getTongThanhTienBanDau() {
        return tongThanhTienBanDau;
    }

    public void setTongThanhTienBanDau(double tongThanhTienBanDau) {
        this.tongThanhTienBanDau = tongThanhTienBanDau;
    }

    public double getTongThanhTienPhaiTra() {
        return tongThanhTienPhaiTra;
    }

    public void setTongThanhTienPhaiTra(double tongThanhTienPhaiTra) {
        this.tongThanhTienPhaiTra = tongThanhTienPhaiTra;
    }

    public HoaDon(int maHoaDon, int khachHang, int khuyenMai, int nhanVien, Date ngayLapHoaDon, double thue, double tongThanhTienBanDau, double tongThanhTienPhaiTra) {
        this.maHoaDon = maHoaDon;
        this.khachHang = khachHang;
        this.khuyenMai = khuyenMai;
        this.nhanVien = nhanVien;
        this.ngayLapHoaDon = ngayLapHoaDon;
        this.thue = thue;
        this.tongThanhTienBanDau = tongThanhTienBanDau;
        this.tongThanhTienPhaiTra = tongThanhTienPhaiTra;
    }
    
    
}
