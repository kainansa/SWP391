/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author MSILap
 */
public class Invoice {
    private int InvoiceID;
    private int BookingID;
    private int PromotionID;
    private int StaffID;
    private Date InvoiceDate;
    private double Tax;
    private double OriginalTotal;
    private double FinalTotal;

    public Invoice(int InvoiceID, int BookingID, int PromotionID, int StaffID, Date InvoiceDate, double Tax, double OriginalTotal, double FinalTotal) {
        this.InvoiceID = InvoiceID;
        this.BookingID = BookingID;
        this.PromotionID = PromotionID;
        this.StaffID = StaffID;
        this.InvoiceDate = InvoiceDate;
        this.Tax = Tax;
        this.OriginalTotal = OriginalTotal;
        this.FinalTotal = FinalTotal;
    }

    public Invoice() {
    }

    public int getInvoiceID() {
        return InvoiceID;
    }

    public void setInvoiceID(int InvoiceID) {
        this.InvoiceID = InvoiceID;
    }

    public int getBookingID() {
        return BookingID;
    }

    public void setBookingID(int BookingID) {
        this.BookingID = BookingID;
    }

    public int getPromotionID() {
        return PromotionID;
    }

    public void setPromotionID(int PromotionID) {
        this.PromotionID = PromotionID;
    }

    public int getStaffID() {
        return StaffID;
    }

    public void setStaffID(int StaffID) {
        this.StaffID = StaffID;
    }

    public Date getInvoiceDate() {
        return InvoiceDate;
    }

    public void setInvoiceDate(Date InvoiceDate) {
        this.InvoiceDate = InvoiceDate;
    }

    public double getTax() {
        return Tax;
    }

    public void setTax(double Tax) {
        this.Tax = Tax;
    }

    public double getOriginalTotal() {
        return OriginalTotal;
    }

    public void setOriginalTotal(double OriginalTotal) {
        this.OriginalTotal = OriginalTotal;
    }

    public double getFinalTotal() {
        return FinalTotal;
    }

    public void setFinalTotal(double FinalTotal) {
        this.FinalTotal = FinalTotal;
    }
    
    
}
