/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.HoaDonChiTiet;


/**
 *
 * @author MSILap
 */
public class BillDetailDAO {
       public static ArrayList<HoaDonChiTiet> getAllBillDetails(String id){
        DBContext db = DBContext.getInstance();
        ArrayList<HoaDonChiTiet> list = new ArrayList<>();
        try {
            String sql = """
                         select * from InvoiceDetail
                         where InvoiceID = ?
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, id);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                     HoaDonChiTiet hoa = new HoaDonChiTiet(rs.getInt("InvoiceDetailID"), 
                                                              rs.getInt("InvoiceID"),
                                                               rs.getInt("ServiceID"),
                                                                 rs.getInt("RoomID"),
                                                                rs.getInt("Quantity"),
                                                       rs.getInt("ReturnedDrinkQuantity"),
                                                             rs.getDouble("RoomRentalTotal"),
                                                               rs.getDouble("ServiceTotal"),
                                                                 rs.getDouble("GrandTotal"), 
                                                                    rs.getDouble("Surcharge"));
                list.add(hoa);
            }
        }catch(Exception e) {
            System.err.println(e);
        }
        if(list.isEmpty()){
            return null;
        }else {
            return list;
        }
    }
}
