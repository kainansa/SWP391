package dao;

import java.sql.*;

public class AccountPointDAO {
    private Connection conn;

    public AccountPointDAO(Connection conn) {
        this.conn = conn;
    }

    // Cộng điểm cho user khi thanh toán
    public void addPoint(int accountId, int addPoint) throws SQLException {
        String sql = "UPDATE AccountPoint SET Point = Point + ?, LastUpdate = GETDATE() WHERE AccountID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, addPoint);
            ps.setInt(2, accountId);
            ps.executeUpdate();
        }
    }

    // Lấy tổng điểm hiện tại
    public int getPoint(int accountId) throws SQLException {
        String sql = "SELECT Point FROM AccountPoint WHERE AccountID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, accountId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("Point");
        }
        return 0;
    }
}
