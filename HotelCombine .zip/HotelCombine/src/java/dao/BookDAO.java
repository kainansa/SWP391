/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import model.Booking;
import model.Rooms;

/**
 *
 * @author admin
 */
public class BookDAO {

    private Connection connection;

    public BookDAO() {
        this.connection = DBContext.getInstance().getConnection();
    }

    public List<Rooms> getAllRooms(int offset, int limit) {
        List<Rooms> roomsList = new ArrayList<>();
        String query = "SELECT * FROM Rooms ORDER BY RoomID DESC OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, offset);
            ps.setInt(2, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Rooms r = new Rooms();
                r.setId(rs.getInt("RoomID"));
                r.setImageUrl(rs.getString("ImageUrl"));
                r.setLocation(rs.getString("Location"));
                r.setDetails(rs.getString("Details"));
                r.setPrice(rs.getString("PricePerNight"));
                r.setRating(rs.getInt("Rating"));
                r.setOriginalPrice(rs.getString("OriginalPrice"));
                roomsList.add(r);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return roomsList;
    }

    public static void main(String[] args) {
        BookDAO dao = new BookDAO();

        // Test getAllRooms
        int offset = 0;
        int limit = 10;
        List<Rooms> rooms = dao.getAllRooms(offset, limit);

        System.out.println("Tổng số phòng tìm thấy: " + rooms.size());
        for (Rooms r : rooms) {
            System.out.println("Room ID: " + r.getId());
            System.out.println("Location: " + r.getLocation());
            System.out.println("Price: " + r.getPrice());
            System.out.println("Image URL: " + r.getImageUrl());
            System.out.println("----------------------");
        }
    }

    public int countAllRooms() {
        try (PreparedStatement ps = connection.prepareStatement("SELECT COUNT(*) FROM Rooms")) {
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public List<Rooms> getAvailableRooms(Date checkin, Date checkout, String type, int offset, int limit) {
        List<Rooms> roomsList = new ArrayList<>();

        String query = "SELECT R.* "
                + "FROM Rooms R "
                + "JOIN RoomTypes RT ON R.RoomTypeID = RT.RoomTypeID "
                + "WHERE (? = 'all' OR RT.TypeName = ?) "
                + "AND R.RoomID NOT IN ( "
                + "    SELECT RoomID FROM Bookings "
                + "    WHERE NOT (CheckOutDate <= ? OR CheckInDate >= ?) "
                + ") "
                + "ORDER BY R.RoomID DESC "
                + "OFFSET ? ROWS FETCH NEXT ? ROWS ONLY;";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, type);  // Cho điều kiện loại phòng
            ps.setString(2, type);
            ps.setDate(3, new java.sql.Date(checkin.getTime()));  // Dùng để so sánh CheckOutDate <= checkin
            ps.setDate(4, new java.sql.Date(checkout.getTime())); // Dùng để so sánh CheckInDate >= checkout
            ps.setInt(5, offset);
            ps.setInt(6, limit);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Rooms r = new Rooms();
                r.setId(rs.getInt("RoomID"));
                r.setImageUrl(rs.getString("ImageUrl"));
                r.setLocation(rs.getString("Location"));
                r.setDetails(rs.getString("Details"));
                r.setPrice(rs.getString("PricePerNight"));
                r.setRating(rs.getInt("Rating"));
                r.setOriginalPrice(rs.getString("OriginalPrice"));
                roomsList.add(r);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return roomsList;
    }

    public int countAvailableRooms(Date checkin, Date checkout, String type) {
        String query = "SELECT COUNT(*) "
            + "FROM Rooms R "
            + "JOIN RoomTypes RT ON R.RoomTypeID = RT.RoomTypeID "
            + "WHERE (? = 'all' OR RT.TypeName = ?) "
            + "AND R.RoomID NOT IN ( "
            + "    SELECT RoomID FROM Bookings "
            + "    WHERE NOT (CheckOutDate <= ? OR CheckInDate >= ?) "
            + ")";
                
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, type);  // Cho điều kiện loại phòng
            ps.setString(2, type);
            ps.setDate(3, new java.sql.Date(checkin.getTime()));  // Dùng để so sánh CheckOutDate <= checkin
            ps.setDate(4, new java.sql.Date(checkout.getTime()));

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    public List<Booking> getBookingByCustomerId(int customerId) {
    List<Booking> list = new ArrayList<>();
    String sql = """
        SELECT *
        FROM Bookings b
        JOIN Rooms r ON b.RoomID = r.RoomID
        WHERE b.CustomerID = ?
        ORDER BY b.BookingDate
    """;

    try (PreparedStatement ps = connection.prepareStatement(sql)) {
        ps.setInt(1, customerId);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Booking booking = new Booking();
            booking.setBookingID(rs.getInt("BookingID"));
            booking.setRoomType(rs.getInt("RoomTypeID")); // mapped with model
            booking.setBookingDate(rs.getDate("BookingDate"));
            booking.setCheckInDate(rs.getDate("CheckInDate"));
            booking.setCheckOutDate(rs.getDate("CheckOutDate"));
            booking.setNumberOfGuests(rs.getInt("NumberOfGuests"));
            booking.setStatus(rs.getString("Status"));
            booking.setCheckInStatus(rs.getString("CheckInStatus"));
            booking.setCheckOutStatus(rs.getString("CheckOutStatus"));
            booking.setPrice(rs.getDouble("PricePerNight")); // mapped with model

            list.add(booking);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return list;
}

}
