/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import model.Package;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Amenity;

/**
 *
 * @author A
 */
public class PackageDAO {

    public List<Package> getAllPackages() {
        List<Package> packages = new ArrayList<>();
        DBContext db = DBContext.getInstance();

        try {
            String sql = "SELECT * FROM Packages";
            PreparedStatement statment = db.getConnection().prepareStatement(sql);
            ResultSet rs = statment.executeQuery();

            while (rs.next()) {
                Package p = new Package();
                p.setId(rs.getInt("id"));
                p.setImageUrl(rs.getString("imageUrl"));
                p.setLocation(rs.getString("location"));
                p.setDetails(rs.getString("details"));
                p.setPrice(rs.getString("price"));
                p.setRating(rs.getInt("rating"));
                p.setOriginalPrice(rs.getString("originalPrice"));
                packages.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return packages;
    }

    

}
