package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBContext {
    private static DBContext instance = new DBContext();
    protected Connection connection;
    public static DBContext getInstance(){
        return instance;
    }

    public Connection getConnection() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url = "jdbc:sqlserver://localhost:1433;instanceName=SQL_SWP391;databaseName=HotelManagement;encrypt=true;trustServerCertificate=true;";
            String user = "sa";
            String password = "123";
            connection = DriverManager.getConnection(url, user, password);
            return connection;
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("Error " + e.getMessage() + " at DBContext");
            return null;
        }
    }

    // Thêm hàm main để test kết nối
    public static void main(String[] args) {
        DBContext db = new DBContext();
        Connection conn = db.getConnection();
        if (conn != null) {
            System.out.println("Kết nối thành công đến database!");
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("Không thể đóng kết nối: " + e.getMessage());
            }
        } else {
            System.out.println("Kết nối thất bại!");
        }
    }
}
