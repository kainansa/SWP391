/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Gallery;

/**
 *
 * @author A
 */
public class GalleryDAO {

    public List<Gallery> getAllGalleries() {
        DBContext db = DBContext.getInstance();
        List<Gallery> galleries = new ArrayList<>();
        try {
            String sql = """
                         SELECT * FROM Gallery
                         """;
            PreparedStatement statment = db.getConnection().prepareStatement(sql);
            ResultSet rs = statment.executeQuery();
            while (rs.next()) {
                Gallery gallery = new Gallery();
                gallery.setImageUrl(rs.getString("imageUrl"));
                gallery.setTitle(rs.getString("title"));
                gallery.setDescription(rs.getString("description"));
                gallery.setLinkUrl(rs.getString("linkUrl"));
                galleries.add(gallery);
            }
        } catch (Exception e) {
             e.printStackTrace();
        }
        return galleries;
    }

}
