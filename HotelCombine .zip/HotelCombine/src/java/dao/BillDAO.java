/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Invoice;
/**
 *
 * @author MSILap
 */
public class BillDAO {
    
   public static ArrayList<Invoice> getAllBill(){
        DBContext db = DBContext.getInstance();
        ArrayList<Invoice> list = new ArrayList<>();
        try {
            String sql = """
                         select * from Invoice
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                Invoice bi = new Invoice(rs.getInt("InvoiceID"),
                                   rs.getInt("BookingID"),
                                   rs.getInt("PromotionID"), 
                                   rs.getInt("StaffID"),
                                   rs.getTimestamp("InvoiceDate"),
                                   rs.getDouble("Tax"),
                                   rs.getDouble("OriginalTotal"),
                                   rs.getDouble("FinalTotal"));
                list.add(bi);
            }
        }catch(Exception e) {
            System.out.println(e);
        }
        if(list.isEmpty()){
            return null;
        }else {
            return list;
        }
    }
    
    public static ArrayList<Invoice> getAllBillSearch(String date){
        DBContext db = DBContext.getInstance();
        ArrayList<Invoice> list = new ArrayList<>();
        try {
            String sql = """
                         select * from Invoice
                         where InvoiceDate = ?
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, date);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                Invoice bi = new Invoice(rs.getInt("InvoiceID"),
                        rs.getInt("BookingID"),
                        rs.getInt("PromotionID"),
                        rs.getInt("StaffID"),
                        rs.getTimestamp("InvoiceDate"),
                        rs.getDouble("Tax"),
                        rs.getDouble("OriginalTotal"),
                        rs.getDouble("FinalTotal"));
                list.add(bi);
            }
        }catch(Exception e) {
            System.err.println(e);
        }
        if(list.isEmpty()){
            return null;
        }else {
            return list;
        }
    }
    
        public static ArrayList<Invoice> getAllBillOrderBy(String date){
        DBContext db = DBContext.getInstance();
        ArrayList<Invoice> list = new ArrayList<>();
        try {
            String sql = """
                         select * from Invoice
                         order by InvoiceDate
                         """;
            sql += " " + date;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                Invoice bi = new Invoice(rs.getInt("InvoiceID"),
                        rs.getInt("BookingID"),
                        rs.getInt("PromotionID"),
                        rs.getInt("StaffID"),
                        rs.getTimestamp("InvoiceDate"),
                        rs.getDouble("Tax"),
                        rs.getDouble("OriginalTotal"),
                        rs.getDouble("FinalTotal"));
                list.add(bi);
            }
        }catch(Exception e) {
            System.err.println(e);
        }
        if(list.isEmpty()){
            return null;
        }else {
            return list;
        }
    }
        
        
        public static ArrayList<Invoice> getAllBillOrderByTotal(String total){
        DBContext db = DBContext.getInstance();
        ArrayList<Invoice> list = new ArrayList<>();
        try {
            String sql = """
                         select * from Invoice
                         order by FinalTotal
                         """;
            sql += " " + total;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                Invoice bi = new Invoice(rs.getInt("InvoiceID"),
                        rs.getInt("BookingID"),
                        rs.getInt("PromotionID"),
                        rs.getInt("StaffID"),
                        rs.getTimestamp("InvoiceDate"),
                        rs.getDouble("Tax"),
                        rs.getDouble("OriginalTotal"),
                        rs.getDouble("FinalTotal"));
                list.add(bi);
            }
        }catch(Exception e) {
            System.err.println(e);
        }
        if(list.isEmpty()){
            return null;
        }else {
            return list;
        }
    }
        
        public static ArrayList<Invoice> getAllBillOrderByPrice(String price){
        DBContext db = DBContext.getInstance();
        ArrayList<Invoice> list = new ArrayList<>();
        try {
            String sql = """
                          select * from Invoice
                          order by Tax
                         """;
            sql += " " + price;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                Invoice bi = new Invoice(rs.getInt("InvoiceID"),
                        rs.getInt("BookingID"),
                        rs.getInt("PromotionID"),
                        rs.getInt("StaffID"),
                        rs.getTimestamp("InvoiceDate"),
                        rs.getDouble("Tax"),
                        rs.getDouble("OriginalTotal"),
                        rs.getDouble("FinalTotal"));
                list.add(bi);
            }
        }catch(Exception e) {
            System.err.println(e);
        }
        if(list.isEmpty()){
            return null;
        }else {
            return list;
        }
    }
        
        public static ArrayList<Invoice> getAllBillSearchYear(String date){
        DBContext db = DBContext.getInstance();
        ArrayList<Invoice> list = new ArrayList<>();
        try {
            String sql = """
                          select * from Invoice
                          where YEAR(InvoiceDate) = ?
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, date);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                Invoice bi = new Invoice(rs.getInt("InvoiceID"),
                        rs.getInt("BookingID"),
                        rs.getInt("PromotionID"),
                        rs.getInt("StaffID"),
                        rs.getTimestamp("InvoiceDate"),
                        rs.getDouble("Tax"),
                        rs.getDouble("OriginalTotal"),
                        rs.getDouble("FinalTotal"));
                list.add(bi);
            }
        }catch(Exception e) {
            System.err.println(e);
        }
        if(list.isEmpty()){
            return null;
        }else {
            return list;
        }
    }
        
            public static ArrayList<Invoice> getAllBillSearchDay(String day, String year){
        DBContext db = DBContext.getInstance();
        ArrayList<Invoice> list = new ArrayList<>();
        try {
            String sql = """
                        select * from Invoice
                         where day(InvoiceDate) = ? and year(InvoiceDate) = ?
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, day);
            statement.setString(2, year);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                Invoice bi = new Invoice(rs.getInt("InvoiceID"),
                        rs.getInt("BookingID"),
                        rs.getInt("PromotionID"),
                        rs.getInt("StaffID"),
                        rs.getTimestamp("InvoiceDate"),
                        rs.getDouble("Tax"),
                        rs.getDouble("OriginalTotal"),
                        rs.getDouble("FinalTotal"));
                list.add(bi);
            }
        }catch(Exception e) {
            System.err.println(e);
        }
        if(list.isEmpty()){
            return null;
        }else {
            return list;
        }
    }
            
        public static ArrayList<Invoice> getAllBillSearchMonth(String month, String year){
        DBContext db = DBContext.getInstance();
        ArrayList<Invoice> list = new ArrayList<>();
        try {
            String sql = """
                         select * from Invoice
                         where month(InvoiceDate) = ? and year(InvoiceDate) = ?
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, month);
            statement.setString(2, year);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                Invoice bi = new Invoice(rs.getInt("InvoiceID"),
                        rs.getInt("BookingID"),
                        rs.getInt("PromotionID"),
                        rs.getInt("StaffID"),
                        rs.getTimestamp("InvoiceDate"),
                        rs.getDouble("Tax"),
                        rs.getDouble("OriginalTotal"),
                        rs.getDouble("FinalTotal"));
                list.add(bi);
            }
        }catch(Exception e) {
            System.err.println(e);
        }
        if(list.isEmpty()){
            return null;
        }else {
            return list;
        }
    }
        
        public static double getAllBillSearchYearSum(String date){
        DBContext db = DBContext.getInstance();
        double total = 0;
        try {
            String sql = """
                         select Sum(FinalTotal) as Total
                         from Invoice
                         where year(InvoiceDate) = ?
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, date);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                  total = rs.getDouble("Total");
            }
        }catch(Exception e) {
            System.err.println(e);
        }
        return total;
    }
        
    public static  double getAllBillSearchDaySum(String day, String year) {
        DBContext db = DBContext.getInstance();
        double total = 0;
        try {
            String sql = """
                         select Sum(FinalTotal) as Total
                         from Invoice
                         where day(InvoiceDate) = ? and year(InvoiceDate) = ?
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, day);
            statement.setString(2, year);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                total = rs.getDouble("Total");
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return total;
    }
    
    public static  double getAllBillSearchMonthSum(String month, String year) {
        DBContext db = DBContext.getInstance();
        double total = 0;
        try {
            String sql = """
                         select Sum(FinalTotal) as Total
                         from Invoice
                         where month(InvoiceDate) = ? and year(InvoiceDate) = ?
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, month);
            statement.setString(2, year);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                total = rs.getDouble("Total");
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return total;
    }
        
    public static  double getAllBillSearchDateSum(String day, String month, String year) {
        DBContext db = DBContext.getInstance();
        double total = 0;
        try {
            String sql = """
                         select Sum(FinalTotal) as Total
                         from Invoice
                         where day(InvoiceDate) = ? and month(InvoiceDate) = ?
                         and year(InvoiceDate) = ?
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, day);
            statement.setString(2, month);
            statement.setString(3, year);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                total = rs.getDouble("Total");
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return total;
    }
    
        public static ArrayList<Invoice> getAllBillSearchDate(String day, String month, String year){
        DBContext db = DBContext.getInstance();
        ArrayList<Invoice> list = new ArrayList<>();
        try {
            String sql = """
                         select * from Invoice
                         where day(InvoiceDate) = ? and month(InvoiceDate) = ?
                         and year(InvoiceDate) = ?
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, day);
            statement.setString(2, month);
            statement.setString(3, year);
            ResultSet rs = statement.executeQuery();
            while(rs.next()){
                Invoice bi = new Invoice(rs.getInt("InvoiceID"),
                        rs.getInt("BookingID"),
                        rs.getInt("PromotionID"),
                        rs.getInt("StaffID"),
                        rs.getTimestamp("InvoiceDate"),
                        rs.getDouble("Tax"),
                        rs.getDouble("OriginalTotal"),
                        rs.getDouble("FinalTotal"));
                list.add(bi);
            }
        }catch(Exception e) {
            System.err.println(e);
        }
        if(list.isEmpty()){
            return null;
        }else {
            return list;
        }
    }    
}
