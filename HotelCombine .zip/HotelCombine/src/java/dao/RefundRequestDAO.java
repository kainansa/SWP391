package dao;

import model.RefundRequest;

import java.sql.*;
import java.util.*;
import java.math.BigDecimal;

public class RefundRequestDAO {

    private Connection conn;

    public RefundRequestDAO(Connection conn) {
        this.conn = conn;
    }

    // Lấy booking của khách hàng (trạng thái 'Active') để refund
    public List<RefundRequest> getActiveBookingsForRefund(int accountId) throws SQLException {
        List<RefundRequest> list = new ArrayList<>();
        String sql = """
            SELECT b.BookingID, b.CustomerID, b.RoomID, b.CheckInDate, b.CheckOutDate, b.Status, r.PricePerNight
            FROM Bookings b
            JOIN Rooms r ON b.RoomID = r.RoomID
            WHERE b.CustomerID = ? AND b.Status = 'Active'
            """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, accountId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                RefundRequest req = new RefundRequest();
                req.setBookingId(rs.getInt("BookingID"));
                req.setAccountId(rs.getInt("CustomerID"));
                req.setRoomId(rs.getInt("RoomID"));
                req.setCheckInDate(rs.getDate("CheckInDate"));
                req.setCheckOutDate(rs.getDate("CheckOutDate"));
                req.setStatus(rs.getString("Status"));
                req.setPrice(BigDecimal.valueOf(rs.getDouble("PricePerNight")));
                list.add(req);
            }
        }
        return list;
    }

    // Lấy booking để tính refund
    public RefundRequest getBookingInfo(int bookingId) throws SQLException {
        String sql = """
            SELECT b.BookingID, b.CustomerID, b.RoomID, b.CheckInDate, b.CheckOutDate, b.Status, r.PricePerNight
            FROM Bookings b
            JOIN Rooms r ON b.RoomID = r.RoomID
            WHERE b.BookingID = ?
            """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookingId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                RefundRequest req = new RefundRequest();
                req.setBookingId(rs.getInt("BookingID"));
                req.setAccountId(rs.getInt("CustomerID"));
                req.setRoomId(rs.getInt("RoomID"));
                req.setCheckInDate(rs.getDate("CheckInDate"));
                req.setCheckOutDate(rs.getDate("CheckOutDate"));
                req.setStatus(rs.getString("Status"));
                req.setPrice(BigDecimal.valueOf(rs.getDouble("PricePerNight")));
                return req;
            }
        }
        return null;
    }

    // Gửi yêu cầu refund (chỉ insert vào bảng RefundRequest)
    public void addRefundRequest(RefundRequest req) throws SQLException {
        String sql = "INSERT INTO RefundRequest (BookingID, AccountID, RoomID, RequestDate, Status, RefundAmount) VALUES (?, ?, ?, GETDATE(), 'Pending', ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, req.getBookingId());
            ps.setInt(2, req.getAccountId());
            ps.setInt(3, req.getRoomId());
            ps.setBigDecimal(4, req.getRefundAmount());
            ps.executeUpdate();
        }
    }
}
