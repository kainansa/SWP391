package dao;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.*;
import java.util.ArrayList;
import model.Account;

public class AccountDAO {

    // PrintAll: Lấy tất cả tài khoản
    public static ArrayList<Account> PrintAll() {
        DBContext db = DBContext.getInstance();
        ArrayList<Account> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Account";
            PreparedStatement statement = db.connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                Account acc = new Account(
                        rs.getInt("account_id"),
                        null, // accountTypeID nếu cần
                        rs.getString("email"),
                        rs.getString("password_hash"),
                        rs.getString("full_name"),
                        rs.getString("phone"),
                        rs.getString("role"),
                        rs.getBoolean("status"),
                        rs.getTimestamp("created_at"),
                        rs.getString("avatar")
                );
                list.add(acc);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        if (list.isEmpty()) {
            return null;
        } else {
            return list;
        }
    }

    // AddAccount: Thêm tài khoản
    public static Account AddAccount(Account acc) {
        DBContext db = DBContext.getInstance();
        int rs = 0;
        try {
            String sql = """
                         INSERT INTO Account (email, password_hash, full_name, phone, role, status, created_at, avatar)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, acc.getEmail());
            statement.setString(2, acc.getPassword_hash());
            statement.setString(3, acc.getFullName());
            statement.setString(4, acc.getPhone());
            statement.setString(5, acc.getRole());
            statement.setBoolean(6, acc.isStatus());
            statement.setTimestamp(7, new Timestamp(acc.getCreatedAt().getTime()));
            statement.setString(8, acc.getAvatar());
            rs = statement.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
        if (rs == 0) {
            return null;
        } else {
            return acc;
        }
    }

    // UpdateAccount: Sửa tài khoản
    public static Account UpdateAccount(Account acc) {
        DBContext db = DBContext.getInstance();
        int rs = 0;
        try {
            String sql = """
                         UPDATE Account
                         SET email = ?, password_hash = ?, full_name = ?, phone = ?, role = ?
                         WHERE account_id = ?
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, acc.getEmail());
            statement.setString(2, acc.getPassword_hash());
            statement.setString(3, acc.getFullName());
            statement.setString(4, acc.getPhone());
            statement.setString(5, acc.getRole());
            statement.setInt(6, acc.getAccountId());
            rs = statement.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
        if (rs == 0) {
            return null;
        } else {
            return acc;
        }
    }

    // DeleteAccount: Xóa tài khoản
    public static boolean DeleteAccount(int accountId) {
        DBContext db = DBContext.getInstance();
        int rs = 0;
        try {
            String sql = "DELETE FROM Account WHERE account_id = ?";
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setInt(1, accountId);
            rs = statement.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
        return rs > 0;
    }

    // getAccountByEmailAndPassword: Đăng nhập
    public Account getAccountByEmailAndPassword(String email, String password) {
        DBContext db = DBContext.getInstance();
        Account account = null;
        try {
            String sql = """
                SELECT * FROM Account
                WHERE email = ? AND password_hash = ? AND status = 1
            """;
            PreparedStatement statement = db.getConnection().prepareStatement(sql);
            statement.setString(1, email);
            statement.setString(2, hashPassword(password));
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                account = new Account();
                account.setAccountId(rs.getInt("account_id"));
                account.setAvatar(rs.getString("avatar"));
                account.setEmail(rs.getString("email"));
                account.setPassword_hash(rs.getString("password_hash"));
                account.setFullName(rs.getString("full_name"));
                account.setPhone(rs.getString("phone"));
                account.setRole(rs.getString("role"));
                account.setStatus(rs.getBoolean("status"));
                account.setCreatedAt(rs.getTimestamp("created_at"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return account;
    }

    // Hàm hash password (SHA-256)
    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // existsByEmail: Kiểm tra tồn tại email
    public boolean existsByEmail(String email) {
        DBContext db = DBContext.getInstance();
        String sql = "SELECT 1 FROM Account WHERE email = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // updatePasswordByEmail: Đổi mật khẩu bằng email
    public boolean updatePasswordByEmail(String email, String newHash) {
        DBContext db = DBContext.getInstance();
        String sql = "UPDATE Account SET password_hash = ? WHERE email = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {
            ps.setString(1, newHash);
            ps.setString(2, email);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // updateProfile: Cập nhật profile
    public boolean updateProfile(Account acc) {
        DBContext db = DBContext.getInstance();
        String sql = "UPDATE Account SET full_name=?, phone=?, avatar=? WHERE account_id=?";
        try {
            PreparedStatement ps = db.getConnection().prepareStatement(sql);
            ps.setString(1, acc.getFullName());
            ps.setString(2, acc.getPhone());
            ps.setString(3, acc.getAvatar());
            ps.setInt(4, acc.getAccountId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // insertAccount: Thêm account (dạng non-static, nếu cần)
    public boolean insertAccount(Account acc) {
        DBContext db = DBContext.getInstance();
        String sql = "INSERT INTO Account (avatar, email, password_hash, full_name, phone, role, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, GETDATE())";
        try {
            PreparedStatement ps = db.getConnection().prepareStatement(sql);
            ps.setString(1, acc.getAvatar());
            ps.setString(2, acc.getEmail());
            ps.setString(3, acc.getPassword_hash());
            ps.setString(4, acc.getFullName());
            ps.setString(5, acc.getPhone());
            ps.setString(6, acc.getRole());
            ps.setBoolean(7, acc.isStatus());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // getAccountById: Lấy account theo id (bản non-static)
    public Account getAccountById(int accountId) {
        DBContext db = DBContext.getInstance();
        String sql = "SELECT * FROM Account WHERE account_id = ?";
        try {
            PreparedStatement ps = db.getConnection().prepareStatement(sql);
            ps.setInt(1, accountId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Account acc = new Account();
                acc.setAccountId(rs.getInt("account_id"));
                acc.setEmail(rs.getString("email"));
                acc.setPassword_hash(rs.getString("password_hash"));
                acc.setFullName(rs.getString("full_name"));
                acc.setPhone(rs.getString("phone"));
                acc.setRole(rs.getString("role"));
                acc.setStatus(rs.getBoolean("status"));
                acc.setCreatedAt(rs.getTimestamp("created_at"));
                acc.setAvatar(rs.getString("avatar"));
                return acc;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // getAccountByEmail: Lấy account theo email
    public Account getAccountByEmail(String email) {
        DBContext db = DBContext.getInstance();
        String sql = "SELECT * FROM Account WHERE email = ?";
        try {
            PreparedStatement ps = db.getConnection().prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Account acc = new Account();
                acc.setAccountId(rs.getInt("account_id"));
                acc.setAvatar(rs.getString("avatar"));
                acc.setEmail(rs.getString("email"));
                acc.setPassword_hash(rs.getString("password_hash"));
                acc.setFullName(rs.getString("full_name"));
                acc.setPhone(rs.getString("phone"));
                acc.setRole(rs.getString("role"));
                acc.setStatus(rs.getBoolean("status"));
                acc.setCreatedAt(rs.getTimestamp("created_at"));
                return acc;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // getAccountByPhone: Lấy account theo phone
    public Account getAccountByPhone(String phone) {
        DBContext db = DBContext.getInstance();
        String sql = "SELECT * FROM Account WHERE phone = ?";
        try {
            PreparedStatement ps = db.getConnection().prepareStatement(sql);
            ps.setString(1, phone);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Account acc = new Account();
                acc.setAccountId(rs.getInt("account_id"));
                acc.setAvatar(rs.getString("avatar"));
                acc.setEmail(rs.getString("email"));
                acc.setPassword_hash(rs.getString("password_hash"));
                acc.setFullName(rs.getString("full_name"));
                acc.setPhone(rs.getString("phone"));
                acc.setRole(rs.getString("role"));
                acc.setStatus(rs.getBoolean("status"));
                acc.setCreatedAt(rs.getTimestamp("created_at"));
                return acc;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
