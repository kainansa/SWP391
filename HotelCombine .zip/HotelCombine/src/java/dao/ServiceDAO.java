/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Services;
/**
 *
 * @author MSILap
 */
public class ServiceDAO {
    
    public static ArrayList<Services> PrintAll(){
        DBContext db = DBContext.getInstance();
        ArrayList<Services> list = new ArrayList<>();
        try {
            String sql = """
                         select * from Services
                         """;
            PreparedStatement statemment = db.connection.prepareStatement(sql);
            ResultSet rs = statemment.executeQuery();
            while(rs.next()){
                Services ser = new Services(rs.getInt("ServiceID"), 
                                           rs.getString("ServiceName"),
                                             rs.getString("Category"),
                                         rs.getDouble("PurchasePrice"),
                                            rs.getDouble("SalePrice"), 
                                          rs.getInt("IsReturnable"),
                                             rs.getInt("Quantity"), 
                                        rs.getTimestamp("ManufactureDate"), 
                                           rs.getTimestamp("ExpiryDate"), 
                                           rs.getString("Description"), 
                                           rs.getString("UsageStatus"));
                list.add(ser);
            }
        }catch(Exception e){
            System.out.println(e);
        }
        if(list.isEmpty()){
            return null;
        }else {
            return list;
        }
    }
    
    public static Services AddService(Services ser) {
        DBContext db = DBContext.getInstance();
        int rs = 0;
        try {
            String sql = """
                         insert into Services (ServiceName, Category, PurchasePrice,
                         SalePrice,IsReturnable,Quantity,ManufactureDate, ExpiryDate,
                         Description,UsageStatus) values (?,?,?,?,?,?,?,?,?,?)
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, ser.getServiceName());
            statement.setString(2, ser.getCategory());
            statement.setDouble(3, ser.getPurchasePrice());
            statement.setDouble(4, ser.getSalePrice());
            statement.setInt(5, ser.getIsReturnable());
            statement.setInt(6, ser.getQuantity());
            statement.setDate(7, new java.sql.Date (ser.getManufactureDate().getTime()));
            statement.setDate(8, new java.sql.Date (ser.getExpiryDate().getTime()));
            statement.setString(9, ser.getDescription());
            statement.setString(10, ser.getUsageStatus());
            rs = statement.executeUpdate();
        }catch(Exception e){
            return null;
        }
        if (rs == 0) {
            return null;
        }else {
            return ser;
        }
    }
    
    public static Services UpdateService(Services ser) {
        DBContext db = DBContext.getInstance();
        int rs = 0;
        try {
            String sql = """
                         update Services set ServiceName = ?,
                         Category = ?, PurchasePrice = ?, 
                         SalePrice = ?, IsReturnable = ?,
                         Quantity = ?, ManufactureDate = ?,
                         ExpiryDate = ?, Description = ?, UsageStatus = ? 
                         where ServiceID = ? 
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setString(1, ser.getServiceName());
            statement.setString(2, ser.getCategory());
            statement.setDouble(3, ser.getPurchasePrice());
            statement.setDouble(4, ser.getSalePrice());
            statement.setInt(5, ser.getIsReturnable());
            statement.setInt(6, ser.getQuantity());
            statement.setDate(7, new java.sql.Date(ser.getManufactureDate().getTime()));
            statement.setDate(8, new java.sql.Date(ser.getExpiryDate().getTime()));
            statement.setString(9, ser.getDescription());
            statement.setString(10, ser.getUsageStatus());
            statement.setInt(11, ser.getServiceID());
            rs = statement.executeUpdate();
        }catch(Exception e){
            return null;
        }
        if(rs == 0){
            return null;
        }else {
            return ser;
        }
    }
    
    public static Services DeleteService(Services ser) {
        DBContext db = DBContext.getInstance();
        int rs = 0;
        try {
            String sql = """
                         delete Services where ServiceID = ?
                         """;
            PreparedStatement statement = db.connection.prepareStatement(sql);
            statement.setInt(1, ser.getServiceID());
            rs = statement.executeUpdate();
        }catch(Exception e){
            return null;
        }
        if(rs == 0){
            return null;
        }else {
            return ser;
        }
    }
    
        public static Services PrintCheck(int ser){
        DBContext db = DBContext.getInstance();
        ArrayList<Services> list = new ArrayList<>();
        try {
            String sql = """
                        select * from Services
                        where ServiceID = ?
                         """;
            PreparedStatement statemment = db.connection.prepareStatement(sql);
            statemment.setInt(1, ser);
            ResultSet rs = statemment.executeQuery();
            while(rs.next()){
                Services sers = new Services(rs.getInt("ServiceID"), 
                                           rs.getString("ServiceName"),
                                             rs.getString("Category"),
                                         rs.getDouble("PurchasePrice"),
                                            rs.getDouble("SalePrice"), 
                                          rs.getInt("IsReturnable"),
                                             rs.getInt("Quantity"), 
                                        rs.getTimestamp("ManufactureDate"), 
                                           rs.getTimestamp("ExpiryDate"), 
                                           rs.getString("Description"), 
                                           rs.getString("UsageStatus"));
                list.add(sers);
            }
        }catch(Exception e){
            System.out.println(e);
        }
        if(list.isEmpty()){
            return null;
        }else {
            return list.get(0);
        }
    }
}
