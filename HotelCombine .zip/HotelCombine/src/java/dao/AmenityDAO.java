/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Amenity;

/**
 *
 * @author A
 */
public class AmenityDAO {
    public List<Amenity> getAmenitiesByPackageId(int packageId) {
        List<Amenity> list = new ArrayList<>();
        DBContext db = DBContext.getInstance();
        try {
            String sql = "SELECT a.id, a.name, a.iconClass FROM Package_Amenities pa "
                    + "JOIN Amenities a ON pa.amenityId = a.id WHERE pa.packageId = ?";
            PreparedStatement statment = db.getConnection().prepareStatement(sql);
            statment.setInt(1, packageId);
            ResultSet rs = statment.executeQuery();
            while (rs.next()) {
                Amenity a = new Amenity(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("iconClass")
                );
                list.add(a);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
