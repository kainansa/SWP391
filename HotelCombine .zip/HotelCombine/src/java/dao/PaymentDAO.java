package dao;

import model.Payment;
import java.sql.*;

public class PaymentDAO {

    private Connection conn;

    public PaymentDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean insertPayment(Payment payment) throws SQLException {
        String sql = "INSERT INTO Payments (AccountID, BookingID, Amount, ServiceAmount, PaymentTime, Status, Note) VALUES (?, ?, ?, ?, GETDATE(), ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, payment.getUserID());
        ps.setInt(2, payment.getBookingID());
        ps.setDouble(3, payment.getAmount());
        ps.setDouble(4, payment.getServiceAmount());
        ps.setString(5, "Pending");
        ps.setString(6, payment.getNote());
        return ps.executeUpdate() > 0;
    }

    public Payment getPaymentById(int paymentId) throws SQLException {
        String sql = "SELECT * FROM Payments WHERE PaymentID=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, paymentId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return new Payment(
                    rs.getInt("PaymentID"),
                    rs.getInt("UserID"),
                    rs.getInt("BookingID"),
                    rs.getInt("Amount"),
                    rs.getInt("ServiceAmount"),
                    rs.getTimestamp("PaymentTime"),
                    rs.getString("Status"),
                    rs.getString("Note"),
                    rs.getString("StaffFeedback"),
                    rs.getInt("StaffID"),
                    rs.getTimestamp("ConfirmedAt")
            );
        }
        return null;
    }

    public boolean confirmPayment(int paymentId, String status, String feedback, int staffId) throws SQLException {
        String sql = "UPDATE Payments SET Status=?, StaffFeedback=?, StaffID=?, ConfirmedAt=GETDATE() WHERE PaymentID=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, status);
        ps.setString(2, feedback);
        ps.setInt(3, staffId);
        ps.setInt(4, paymentId);
        return ps.executeUpdate() > 0;
    }
}
