/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import model.RoomDetail;
import java.sql.ResultSet;


/**
 *
 * @author admin
 */
public class RoomDetailDAO {
    private Connection connection;

    public RoomDetailDAO() {
        this.connection = DBContext.getInstance().getConnection();
    }
    public RoomDetail getRoomDetailById(int roomId) {
    RoomDetail detail = null;
    String query = "SELECT * FROM RoomDetail WHERE RoomID = ?";

    try (PreparedStatement ps = connection.prepareStatement(query)) {
        ps.setInt(1, roomId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            detail = new RoomDetail();
            detail.setId(rs.getInt("RoomID"));
            detail.setDescription(rs.getString("Description"));
            detail.setImage1(rs.getString("Image1"));
            detail.setImage2(rs.getString("Image2"));
            detail.setImage3(rs.getString("Image3"));
            detail.setImage4(rs.getString("Image4"));          
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return detail;
}
    public static void main(String[] args) {
    RoomDetailDAO dao = new RoomDetailDAO();

    int testId = 2; // bạn có thể đổi thành ID muốn kiểm tra
    RoomDetail detail = dao.getRoomDetailById(testId);

    if (detail != null) {
        System.out.println("✅ Room found:");
        System.out.println("ID: " + detail.getId());
        System.out.println("Description: " + detail.getDescription());
        System.out.println("Image1: " + detail.getImage1());
        System.out.println("Image2: " + detail.getImage2());
        System.out.println("Image3: " + detail.getImage3());
        System.out.println("Image4: " + detail.getImage4());
    } else {
        System.out.println("❌ Không tìm thấy phòng với ID: " + testId);
    }
}



}
