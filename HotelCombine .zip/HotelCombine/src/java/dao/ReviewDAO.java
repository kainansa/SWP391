/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Review;

/**
 *
 * @author A
 */
public class ReviewDAO {

    public List<Review> getAllReviews() {
        DBContext db = DBContext.getInstance();
        List<Review> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Reviews";
            PreparedStatement statment = db.getConnection().prepareStatement(sql);
            ResultSet rs = statment.executeQuery();
            while (rs.next()) {
                Review r = new Review();
                r.setReviewId(rs.getInt("reviewId"));
                r.setName(rs.getString("name"));
                r.setContent(rs.getString("content"));
                r.setImageUrl(rs.getString("imageUrl"));
                r.setRating(rs.getInt("rating"));
                list.add(r);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
