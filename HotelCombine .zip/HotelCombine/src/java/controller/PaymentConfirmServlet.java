package controller;

import dao.PaymentDAO;
import model.Payment;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;


public class PaymentConfirmServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, jakarta.servlet.http.HttpServletResponse response)
            throws ServletException, IOException {
        int paymentId = Integer.parseInt(request.getParameter("paymentId"));
        Connection conn = (Connection) getServletContext().getAttribute("DBConnection");
        PaymentDAO paymentDAO = new PaymentDAO(conn);
        Payment payment = null;
        try {
            payment = paymentDAO.getPaymentById(paymentId);
        } catch (Exception e) {
            request.setAttribute("message", "Lỗi khi lấy dữ liệu: " + e.getMessage());
        }
        request.setAttribute("payment", payment);
        request.getRequestDispatcher("PaymentConf.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, jakarta.servlet.http.HttpServletResponse response)
            throws ServletException, IOException {
        int paymentId = Integer.parseInt(request.getParameter("paymentId"));
        String status = request.getParameter("status");
        String feedback = request.getParameter("feedback");
        Integer staffId = (Integer) request.getSession().getAttribute("staffId");
        if (staffId == null) staffId = 1;

        Connection conn = (Connection) getServletContext().getAttribute("DBConnection");
        PaymentDAO paymentDAO = new PaymentDAO(conn);
        String message = "";
        try {
            if(paymentDAO.confirmPayment(paymentId, status, feedback, staffId)){
                message = "Cập nhật xác nhận thành công!";
            } else {
                message = "Không tìm thấy giao dịch!";
            }
        } catch (Exception e) {
            message = "Lỗi khi xác nhận: " + e.getMessage();
        }
        request.setAttribute("message", message);
        doGet(request, response);
    }
}
