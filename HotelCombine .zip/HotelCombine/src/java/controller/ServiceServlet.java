/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package controller;

import dao.ServiceDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Services;

/**
 *
 * @author MSILap
 */
public class ServiceServlet extends HttpServlet {
   
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ServiceServlet</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ServiceServlet at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
     throws ServletException, IOException {
         ArrayList<Services> list;
        String action = request.getParameter("action");
        String ServiceID = request.getParameter("id");
        int id = 0;
        try {
            id = Integer.parseInt(ServiceID);
        }catch(NumberFormatException e){
            list = ServiceDAO.PrintAll();
            request.setAttribute("list", list);
            request.getRequestDispatcher("view/Services.jsp").forward(request, response);
            return;
        }
         if(action.equals("DELETE")){
                Services vice = ServiceDAO.PrintCheck(id);
                vice = ServiceDAO.DeleteService(vice);
                list = ServiceDAO.PrintAll();
                request.setAttribute("list", list);
                if (vice != null) {
                    request.setAttribute("message", "Delete Service Sucessfull");
                } else {
                    request.setAttribute("error", "Delete Service Failer!!!");
                }
                request.getRequestDispatcher("view/Services.jsp").forward(request, response);
            }

    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        ArrayList<Services> list;
        String action = request.getParameter("action");
        String ServiceName = request.getParameter("name");
        String Category = request.getParameter("cate");
        String PurchasePrice = request.getParameter("pur");
        String SalePrice = request.getParameter("sale");
        String IsReturnable = request.getParameter("is");
        String Quantity = request.getParameter("quantity");
        String ManufactureDate = request.getParameter("date");
        String ExpiryDate = request.getParameter("dates");
        String Description = request.getParameter("des");
        String UsageStatus = request.getParameter("usage");
        String ServiceID = request.getParameter("id");
        double purch = 0, price = 0;
        int is = 0,quan = 0;
        int id = 0;
        java.util.Date manu = null;
        java.util.Date exp = null;
           try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            manu = sdf.parse(ManufactureDate);
            exp = sdf.parse(ExpiryDate);
            purch = Double.parseDouble(PurchasePrice);
            price = Double.parseDouble(SalePrice);
            is = Integer.parseInt(IsReturnable);
            quan = Integer.parseInt(Quantity);
        }catch(NumberFormatException e){
            list = ServiceDAO.PrintAll();
            request.setAttribute("list", list);
            request.setAttribute("error", "Please enter number.Do not enter letter");
            request.getRequestDispatcher("view/Services.jsp").forward(request, response);
            return;
        } catch (ParseException ex) {
            Logger.getLogger(ServiceServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
           if(action.equals("ADD")){
            Services ce = new Services(0, ServiceName, Category, purch, price, is, quan, manu, exp, Description, UsageStatus);
            ce = ServiceDAO.AddService(ce);
            request.setAttribute("ce", ce);
            list = ServiceDAO.PrintAll();
            request.setAttribute("list", list);
            if(ce != null){
                request.setAttribute("message", "Add Service Sucessfull");
            }else {
                request.setAttribute("error", "Add Service Failer!!!");
            }
            request.getRequestDispatcher("view/Services.jsp").forward(request, response);
            return;
        }else if (action.equals("UPDATE")){
               try {
                   id = Integer.parseInt(ServiceID);
               }catch (NumberFormatException e){
                   list = ServiceDAO.PrintAll();
                   request.setAttribute("list", list);
                   request.setAttribute("error", "Please enter number.Do not enter letter");
                   request.getRequestDispatcher("view/Services.jsp").forward(request, response);
               }
               Services ce = new Services(id, ServiceName, Category, purch, price, is, quan, manu, exp, Description, UsageStatus);
               ce = ServiceDAO.UpdateService(ce);
               list = ServiceDAO.PrintAll();
               request.setAttribute("list", list);
               if (ce != null) {
                   request.setAttribute("message", "Update Service Sucessfull");
               } else {
                   request.setAttribute("error", "Update Service Failer!!!");
               }
               request.getRequestDispatcher("view/Services.jsp").forward(request, response);
               return;
             }
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
