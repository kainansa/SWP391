package controller;

import dao.RoomDetailDAO;
import model.RoomDetail;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public class RoomDetailServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String idRaw = request.getParameter("id");

            if (idRaw == null || idRaw.trim().isEmpty()) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing room ID");
                return;
            }

            int roomId = Integer.parseInt(idRaw);
            RoomDetailDAO dao = new RoomDetailDAO();
            RoomDetail detail = dao.getRoomDetailById(roomId);

            if (detail == null) {
                System.out.println("Không tìm thấy phòng với ID: " + roomId);
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Room not found");
                return;
            }

            // Nếu tìm thấy, chuyển tiếp sang JSP
            request.setAttribute("detail", detail);
            request.getRequestDispatcher("/view/roomDetail.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid room ID format");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Internal server error");
        }
    }
}
