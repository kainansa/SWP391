package controller;

import dao.PaymentDAO;
import model.Payment;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

@WebServlet("/payment")
public class PaymentServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("payment.jsp").forward(request, response);
    }

    @Override
   
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    double amount = Double.parseDouble(request.getParameter("amount"));
    String roomType = request.getParameter("roomType");
    int serviceCount = Integer.parseInt(request.getParameter("serviceCount"));

    Integer userId = (Integer) request.getSession().getAttribute("userId");
    Integer bookingId = (Integer) request.getSession().getAttribute("bookingId");
    if (userId == null) userId = 1; // test tạm
    if (bookingId == null) bookingId = 1;

    Payment payment = new Payment();
    payment.setUserID(userId);
    payment.setBookingID(bookingId);
    payment.setAmount(amount);
    payment.setServiceAmount(0); // nếu có phí dịch vụ thì lấy đúng
    payment.setNote("Thanh toán chuyển khoản: " + roomType + ", số dịch vụ: " + serviceCount);

    String message;
    Connection conn = null;
    try {
        // Tạo connection mới mỗi lần dùng
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://localhost:1433;databaseName=HotelManagement";
        String user = "sa";
        String password = "123";
        conn = DriverManager.getConnection(url, user, password);

        PaymentDAO paymentDAO = new PaymentDAO(conn);
        boolean success = paymentDAO.insertPayment(payment);
        if (success) {
            message = "Cảm ơn bạn đã thanh toán! Chúng tôi sẽ xác nhận sớm nhất.";

            // === TÍCH ĐIỂM VÀ PHÂN HẠNG NGƯỜI DÙNG ===
            try {
                dao.AccountPointDAO pointDAO = new dao.AccountPointDAO(conn);
                int addPoint = (int) (amount / 10);   // Mỗi 10k được 1 điểm
                pointDAO.addPoint(userId, addPoint);

                int totalPoint = pointDAO.getPoint(userId);
                int accountType = getAccountTypeByPoint(totalPoint); // 1=Stander, 2=VIP, 3=SVIP

                // (Tùy chọn) Gửi accountType ra request/session nếu muốn hiển thị trên giao diện
                request.setAttribute("accountType", accountType);

            } catch (Exception ex) {
                ex.printStackTrace();
            }
            // === END TÍCH ĐIỂM ===

        } else {
            message = "Có lỗi xảy ra khi lưu thanh toán, vui lòng thử lại.";
        }
    } catch (Exception e) {
        message = "Lỗi hệ thống: " + e.getMessage();
    } finally {
        if (conn != null) try { conn.close(); } catch (Exception ex) {}
    }
    request.setAttribute("message", message);
    request.getRequestDispatcher("payment.jsp").forward(request, response);
}

    public int getAccountTypeByPoint(int point) {
    if (point < 1200) return 1;       // Stander
    else if (point < 5000) return 2;  // VIP
    else return 3;                    // SVIP
}
    
}
