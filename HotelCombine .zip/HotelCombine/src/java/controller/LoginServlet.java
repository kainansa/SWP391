/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.AccountDAO;
import dao.AmenityDAO;
import dao.GalleryDAO;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Employees;
import dao.PackageDAO;
import jakarta.servlet.http.Cookie;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.List;
import model.Account;
import model.Amenity;
import model.Gallery;
import model.Package;

/**
 *
 * @author A
 */
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LoginServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet LoginServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie c : cookies) {
                if ("email".equals(c.getName())) {
                    request.setAttribute("email", c.getValue());
                    break;
                }
            }
        }
        request.setAttribute("showLogin", true);

        PackageDAO packageDAO = new PackageDAO();
        AmenityDAO amenityDao = new AmenityDAO();
        List<Package> packages = packageDAO.getAllPackages();
        for (Package pkg : packages) {
            List<Amenity> ams = amenityDao.getAmenitiesByPackageId(pkg.getId());
            if (ams.size() > 3) {
                ams = ams.subList(0, 3);
            }
            pkg.setAmenities(ams);
        }
        request.setAttribute("packages", packages);

        GalleryDAO galleryDAO = new GalleryDAO();
        List<Gallery> galleryList = galleryDAO.getAllGalleries();
        request.setAttribute("galleryList", galleryList);

        request.getRequestDispatcher("home").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            boolean remember = request.getParameter("remember") != null;

            AccountDAO dao = new AccountDAO();
            Account account = dao.getAccountByEmailAndPassword(email, password);

            if (account == null) {
                String error = "Not match username and password! Please try again!";
                request.setAttribute("showLogin", true);
                request.setAttribute("errorMessage", error);

                PackageDAO packageDAO = new PackageDAO();
                AmenityDAO amenityDao = new AmenityDAO();
                List<Package> packages = packageDAO.getAllPackages();
                for (Package pkg : packages) {
                    List<Amenity> ams = amenityDao.getAmenitiesByPackageId(pkg.getId());
                    if (ams.size() > 3) {
                        ams = ams.subList(0, 3);
                    }
                    pkg.setAmenities(ams);
                }
                request.setAttribute("packages", packages);

                GalleryDAO galleryDAO = new GalleryDAO();
                List<Gallery> galleryList = galleryDAO.getAllGalleries();
                request.setAttribute("galleryList", galleryList);

                RequestDispatcher rs = request.getRequestDispatcher("home.jsp");
                rs.forward(request, response);
            } else {
                HttpSession session = request.getSession();
                session.setAttribute("user", account);  // Lưu account vào session
                session.setAttribute("userId", account.getAccountId());
                session.setAttribute("role", account.getRole());

                String avatar = account.getAvatar();
                if (avatar == null || avatar.isEmpty()) {
                    avatar = "img/default.jpg"; 
                }
                session.setAttribute("avatar", avatar);
                
                session.removeAttribute("showLogin");

                Cookie emailCookie = new Cookie("email", remember ? email : "");
                emailCookie.setMaxAge(remember ? 60 * 60 * 24 * 7 : 0); // 7 days or remove
                response.addCookie(emailCookie);

                // Chuyển hướng tùy role:
                if ("manager".equalsIgnoreCase(account.getRole())) {
                    response.sendRedirect("ManagerDashboard.jsp");
                } else if ("staff".equalsIgnoreCase(account.getRole())) {
                    response.sendRedirect("StaffDashboard.jsp");
                } else if ("admin".equalsIgnoreCase(account.getRole())) {
                    response.sendRedirect("admin/dashboard.jsp");
                } else {
                    // Mặc định chuyển về home cho customer
                    response.sendRedirect("home");
                }
            }
           
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
