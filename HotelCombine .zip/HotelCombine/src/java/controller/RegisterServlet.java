/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.*;
import model.Account;
import dao.AccountDAO;
import java.io.File;
import java.security.MessageDigest;

/**
 *
 * @author A
 */
@MultipartConfig
public class RegisterServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegisterServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet RegisterServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String hashedPassword = hashPassword(password);
        String phone = request.getParameter("phone");
        String avatarPath = null;

        Part filePart = request.getPart("avatar");
        String submittedFileName = filePart != null ? filePart.getSubmittedFileName() : null;

        if (filePart != null
                && filePart.getSize() > 0
                && submittedFileName != null
                && !submittedFileName.isEmpty()) {
            // Upload file
            String fileName = "avt_" + System.currentTimeMillis() + "_" + (email != null ? email.hashCode() : "user") + ".png";
            String uploadFolder = getServletContext().getRealPath("/img");
            File folder = new File(uploadFolder);
            if (!folder.exists()) {
                folder.mkdirs();
            }
            if (!uploadFolder.endsWith(File.separator)) {
                uploadFolder += File.separator;
            }
            String savePath = uploadFolder + fileName;
            System.out.println("Upload folder: " + uploadFolder);
            System.out.println("Save path: " + savePath);
            filePart.write(savePath);

            avatarPath = fileName;
        } else {
            avatarPath = null;
        }
        System.out.println("filePart: " + filePart);
        System.out.println("filePart.getSize(): " + (filePart != null ? filePart.getSize() : "null"));
        System.out.println("submittedFileName: " + submittedFileName);
        System.out.println("avatarPath: " + avatarPath);

        AccountDAO dao = new AccountDAO();
        // Kiểm tra phone phải là 10 chữ số
        if (phone == null || !phone.matches("\\d{10}")) {
            request.setAttribute("error", "Phone number must be exactly 10 digits.");
            request.getRequestDispatcher("view/register.jsp").forward(request, response);
            return;
        }

        if (dao.getAccountByEmail(email) != null || dao.getAccountByPhone(phone) != null) {
            request.setAttribute("error", "Email or Phone is already registered!");
            request.getRequestDispatcher("view/register.jsp").forward(request, response);
            return;
        }

        // Tạo Account (chưa lưu DB)
        Account acc = new Account();
        acc.setFullName(fullName);
        acc.setEmail(email);
        acc.setPassword_hash(hashedPassword);
        acc.setPhone(phone);
        acc.setAvatar(avatarPath);
        acc.setRole("customer");
        acc.setStatus(true);

        // Sinh OTP
        int otp = 100000 + new java.util.Random().nextInt(900000);

        // Lưu vào session
        HttpSession session = request.getSession();
        session.setAttribute("pendingAccount", acc);
        session.setAttribute("otp", otp);
        session.setAttribute("otp_time", System.currentTimeMillis()); 
        // Gửi OTP qua email
        service.EmailService emailService = new service.EmailService();
        try {
            emailService.sendOtpEmail(email, String.valueOf(otp));
            // Chuyển hướng sang trang nhập OTP
            response.sendRedirect(request.getContextPath() + "/view/otp.jsp");
        } catch (Exception e) {
            request.setAttribute("error", "Cannot send OTP! Try again.");
            request.getRequestDispatcher("view/register.jsp").forward(request, response);
        }
    }

    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(password.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
