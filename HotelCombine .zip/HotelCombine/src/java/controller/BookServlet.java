/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.BookDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import model.Rooms;

/**
 *
 * @author admin
 */
public class BookServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String checkinStr = request.getParameter("checkin");
        String checkoutStr = request.getParameter("checkout");
        String type = request.getParameter("type");
        String pageStr = request.getParameter("page");

        int page = (pageStr != null) ? Integer.parseInt(pageStr) : 1;
        int limit = 6;
        int offset = (page - 1) * limit;

        BookDAO dao = new BookDAO();

        try {
            if (checkinStr == null || checkinStr.isEmpty()
                    || checkoutStr == null || checkoutStr.isEmpty()
                    || type == null || type.isEmpty()) {
                List<Rooms> rooms = dao.getAllRooms(offset, limit);
                int totalRooms = dao.countAllRooms();
                int totalPages = (int) Math.ceil((double) totalRooms / limit);

                request.setAttribute("rooms", rooms);
                request.setAttribute("currentPage", page);
                request.setAttribute("totalPages", totalPages);
                request.getRequestDispatcher("/view/Book.jsp").forward(request, response);
                return;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date checkin = sdf.parse(checkinStr);
            Date checkout = sdf.parse(checkoutStr);

            List<Rooms> rooms = dao.getAvailableRooms(checkin, checkout, type, offset, limit);
            int totalRooms = dao.countAvailableRooms(checkin, checkout, type);
            int totalPages = (int) Math.ceil((double) totalRooms / limit);

            request.setAttribute("rooms", rooms);
            request.setAttribute("checkin", checkinStr);
            request.setAttribute("checkout", checkoutStr);
            request.setAttribute("type", type);
            request.setAttribute("currentPage", page);
            request.setAttribute("totalPages", totalPages);
            request.getRequestDispatcher("/view/Book.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Invalid input!");
            request.getRequestDispatcher("/view/Book.jsp").forward(request, response);
        }
    }
}
