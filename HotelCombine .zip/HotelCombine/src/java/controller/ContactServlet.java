/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.GalleryDAO;
import dao.ReviewDAO;
import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import java.util.Properties;
import model.Gallery;
import model.Review;

/**
 *
 * @author A
 */

public class ContactServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ContactServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ContactServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Object user = (session != null) ? session.getAttribute("user") : null;

        if (user == null) {
            // Chưa login, trở về home và show popup login
            request.setAttribute("showLogin", true);
            request.setAttribute("errorMessage", "You need to login to submit contact!");

            GalleryDAO galleryDAO = new GalleryDAO();
            List<Gallery> galleryList = galleryDAO.getAllGalleries();
            request.setAttribute("galleryList", galleryList);

            ReviewDAO reviewDAO = new ReviewDAO();
            List<Review> reviewList = reviewDAO.getAllReviews();
            request.setAttribute("reviewList", reviewList);
            request.getRequestDispatcher("home.jsp").forward(request, response);
            return;
        }

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String title = request.getParameter("title");
        String message = request.getParameter("message");

        if (name == null || name.trim().isEmpty()
                || email == null || email.trim().isEmpty()
                || phone == null || phone.trim().isEmpty()
                || title == null || title.trim().isEmpty()
                || message == null || message.trim().isEmpty()) {

           
            request.setAttribute("name", name);
            request.setAttribute("email", email);
            request.setAttribute("phone", phone);
            request.setAttribute("title", title);
            request.setAttribute("message", message);

            request.setAttribute("error", "Contact sending failed! Please try again later.");
            request.getRequestDispatcher("view/contact-error.jsp").forward(request, response);
            return;
        }

        
        service.EmailService emailService = new service.EmailService();

        try {
            // Gửi email tới hòm thư quản lý 
            emailService.sendContactEmail(
                    "caubevanhungconmua@gmail.com",
                    name,
                    email,
                    phone,
                    title,
                    message
            );

            // Sau khi gửi thành công,chuyển sang trang thông báo thành công
            request.setAttribute("message", "Contact sent successfully! We will respond soon.");
            request.getRequestDispatcher("view/contact-success.jsp").forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
            // Nếu gửi thất bại, chuyển sang trang báo lỗi
            request.setAttribute("error", "Contact sending failed! Please try again later.");
            request.getRequestDispatcher("view/contact-error.jsp").forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
