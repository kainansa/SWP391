/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package controller;

import dao.BillDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import model.Invoice;

/**
 *
 * @author MSILap
 */
public class StatisticalServlet extends HttpServlet {
   
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet StatisticalServlet</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet StatisticalServlet at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
       String day = request.getParameter("day");
       String month = request.getParameter("month");
       String year = request.getParameter("year");
       String action = request.getParameter("action");
       ArrayList<Invoice> list;
       double total = 0;
       if(action == null) {
           list = BillDAO.getAllBill();
           request.setAttribute("list", list);
           request.getRequestDispatcher("view/Statistical.jsp").forward(request, response);
       }else if (action.equals("Total")) {
           try {
               if (!day.isEmpty()) {
                   Integer.parseInt(day);
               }
               if (!month.isEmpty()) {
                   Integer.parseInt(month);
               }
               if (!year.isEmpty()){
                   Integer.parseInt(year);
               }
           }catch(NumberFormatException e) {
               list = BillDAO.getAllBill();
               request.setAttribute("list", list);
               request.setAttribute("message", "Please enter number.Do not enter letter");
               request.getRequestDispatcher("view/Statistical.jsp").forward(request, response);
               return;
            }
           
           if (!day.isEmpty() && !month.isEmpty() && !year.isEmpty()){
               list = BillDAO.getAllBillSearchDate(day, month, year);
               total = BillDAO.getAllBillSearchDateSum(day, month, year);
               request.setAttribute("list", list);
               request.setAttribute("total", total);
               request.getRequestDispatcher("view/Statistical.jsp").forward(request, response);
           }else if(!year.isEmpty() && !day.isEmpty()) {
               list = BillDAO.getAllBillSearchDay(day, year);
               total = BillDAO.getAllBillSearchDaySum(day, year);
               request.setAttribute("list", list);
               request.setAttribute("total", total);
               request.getRequestDispatcher("view/Statistical.jsp").forward(request, response);
           }else if (!year.isEmpty() && !month.isEmpty()){
               list = BillDAO.getAllBillSearchMonth(month, year);
               total = BillDAO.getAllBillSearchMonthSum(month, year);
               request.setAttribute("list", list);
               request.setAttribute("total", total);
               request.getRequestDispatcher("view/Statistical.jsp").forward(request, response);
           }else if (!year.isEmpty()) {
               list = BillDAO.getAllBillSearchYear(year);
               total = BillDAO.getAllBillSearchYearSum(year);
               request.setAttribute("list", list);
               request.setAttribute("total", total);
               request.getRequestDispatcher("view/Statistical.jsp").forward(request, response);
           }else if (year.isEmpty() || day.isEmpty() || month.isEmpty()) {
               list = BillDAO.getAllBill();
               request.setAttribute("list", list);
               request.setAttribute("message", "You enter not information.Please enter in day or month,year");
               request.getRequestDispatcher("view/Statistical.jsp").forward(request, response);
           }
       }else if(action.equals("All")){
           list = BillDAO.getAllBill();
           request.setAttribute("list", list);
           request.getRequestDispatcher("view/Statistical.jsp").forward(request, response);
       }
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
