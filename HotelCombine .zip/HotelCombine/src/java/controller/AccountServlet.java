package controller;

import dao.AccountDAO;
import model.Account;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

public class AccountServlet extends HttpServlet {

    private AccountDAO accountDAO;

    @Override
    public void init() throws ServletException {
        accountDAO = new AccountDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "home";
        }

        switch (action) {
            case "home":
                showHome(request, response);
                break;
            case "list":
                listAccounts(request, response);
                break;
            case "add":
                showAddForm(request, response);
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "delete":
                deleteAccount(request, response);
                break;
            default:
                showHome(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }

        switch (action) {
            case "add":
                addAccount(request, response);
                break;
            case "update":
                updateAccount(request, response);
                break;
            default:
                showHome(request, response);
                break;
        }
    }

    private void showHome(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/view/home.jsp").forward(request, response);
    }

    private void listAccounts(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<Account> accounts = accountDAO.PrintAll();
        request.setAttribute("accounts", accounts);
        request.getRequestDispatcher("/view/account_list.jsp").forward(request, response);
    }

    private void showAddForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/view/account_add.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int accountId = Integer.parseInt(request.getParameter("id"));
        Account account = accountDAO.getAccountById(accountId);
        request.setAttribute("account", account);
        request.getRequestDispatcher("/view/account_edit.jsp").forward(request, response);
    }

    private void addAccount(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Account account = new Account();
        account.setEmail(request.getParameter("email"));
        account.setPassword_hash(request.getParameter("password"));
        account.setFullName(request.getParameter("fullName"));
        account.setPhone(request.getParameter("phone"));
        account.setRole(request.getParameter("role") != null ? request.getParameter("role") : "Staff");
        account.setStatus(false); // Default offline
        account.setCreatedAt(new Date());
        account.setAvatar(null); // Assuming avatar is optional

        Account result = accountDAO.AddAccount(account);
        if (result != null) {
            response.sendRedirect("AccountServlet?action=list");
        } else {
            request.setAttribute("error", "Failed to add account");
            request.getRequestDispatcher("/view/account_add.jsp").forward(request, response);
        }
    }

    private void updateAccount(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int accountId = Integer.parseInt(request.getParameter("accountId"));
        Account account = new Account();
        account.setAccountId(accountId);
        account.setEmail(request.getParameter("email"));
        account.setPassword_hash(request.getParameter("password"));
        account.setFullName(request.getParameter("fullName"));
        account.setPhone(request.getParameter("phone"));
        account.setRole(request.getParameter("role"));

        Account result = accountDAO.UpdateAccount(account);
        if (result != null) {
            response.sendRedirect("AccountServlet?action=list");
        } else {
            request.setAttribute("error", "Failed to update account");
            request.setAttribute("account", account);
            request.getRequestDispatcher("/view/account_edit.jsp").forward(request, response);
        }
    }

    private void deleteAccount(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int accountId = Integer.parseInt(request.getParameter("id"));
        boolean success = accountDAO.DeleteAccount(accountId);
        if (success) {
            response.sendRedirect("AccountServlet?action=list");
        } else {
            request.setAttribute("error", "Failed to delete account");
            listAccounts(request, response);
        }
    }
}
