package controller;

import dao.RefundRequestDAO;
import dao.AccountPointDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import model.RefundRequest;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.util.Date;
import java.util.List;


public class RefundRoomServlet extends HttpServlet {

    // Hàm xác định loại hạng từ điểm (dán đầu file hoặc cuối file)
    private int getAccountTypeByPoint(int point) {
        if (point < 1200) return 1;       // Stander
        else if (point < 5000) return 2;  // VIP
        else return 3;                    // SVIP
    }
    

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Integer userId = (Integer) request.getSession().getAttribute("userId");
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        try (Connection conn = dao.DBContext.getInstance().getConnection()) {
            RefundRequestDAO refundDAO = new RefundRequestDAO(conn);
            List<RefundRequest> bookingList = refundDAO.getActiveBookingsForRefund(userId);
            request.setAttribute("bookingList", bookingList);
            request.getRequestDispatcher("refundRoom.jsp").forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
            response.sendError(500);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Integer userId = (Integer) request.getSession().getAttribute("userId");
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        try (Connection conn = dao.DBContext.getInstance().getConnection()) {
            int bookingId = Integer.parseInt(request.getParameter("bookingId"));
            RefundRequestDAO refundDAO = new RefundRequestDAO(conn);

            // Lấy thông tin booking cần refund
            RefundRequest booking = refundDAO.getBookingInfo(bookingId);

            // Lấy điểm hiện tại của user
            AccountPointDAO pointDAO = new AccountPointDAO(conn);
            int totalPoint = pointDAO.getPoint(userId);
            int accountTypeId = getAccountTypeByPoint(totalPoint);

            // Tính tiền hoàn lại dựa theo hạng
            BigDecimal refundAmount = calculateRefund(
                    accountTypeId,
                    booking.getCheckInDate(),
                    new Date(),
                    booking.getPrice()
            );

            booking.setRefundAmount(refundAmount);
            refundDAO.addRefundRequest(booking);
            response.sendRedirect("RefundRoomServlet?success=1");

        } catch (Exception ex) {
            ex.printStackTrace();
            response.sendRedirect("RefundRoomServlet?error=1");
        }
    }

    // Hàm tính tiền hoàn lại
    private BigDecimal calculateRefund(int accountTypeId, java.util.Date checkIn, java.util.Date now, BigDecimal totalPrice) {
        long diff = checkIn.getTime() - now.getTime();
        long days = diff / (1000 * 60 * 60 * 24);
        if (accountTypeId == 1) { // Stander
            if (days >= 3) return totalPrice.multiply(new BigDecimal("0.8"));
        } else if (accountTypeId == 2) { // VIP
            if (days >= 1) return totalPrice.multiply(new BigDecimal("0.8"));
        } else if (accountTypeId == 3) { // SVIP
            if (days >= 1) return totalPrice.multiply(new BigDecimal("0.9"));
        }
        return BigDecimal.ZERO;
    }
}
